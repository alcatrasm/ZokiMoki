import { Inter } from 'next/font/google';
import './globals.css';
import { getSettings } from '@/lib/database';

const inter = Inter({ subsets: ['latin'] });

export const runtime = 'edge';

export async function generateMetadata() {
  const settings = await getSettings();
  
  return {
    title: settings.site_name || 'Zokimoki',
    description: settings.site_description || 'The best HTML5 gaming platform',
  };
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="tr">
      <body className={inter.className}>
        {children}
      </body>
    </html>
  );
}
