import { cookies } from 'next/headers';
import { getCloudflareContext } from '@/lib/database';

export const runtime = 'edge';

export async function GET() {
  const cookieStore = cookies();
  const theme = cookieStore.get('theme')?.value || 'light';
  
  // Get Cloudflare context for database access
  const ctx = getCloudflareContext();
  
  // Check if database is available
  const dbStatus = ctx ? 'connected' : 'not connected';
  
  return Response.json({
    message: 'Zokimoki API is running',
    theme,
    database: dbStatus,
    timestamp: new Date().toISOString()
  });
}
