import { getSettings, getAllGames } from '@/lib/database';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import GameCard from '@/components/GameCard';
import Link from 'next/link';
import { Suspense } from 'react';

export const runtime = 'edge';

export default async function GamesPage({
  searchParams,
}: {
  searchParams: { [key: string]: string | string[] | undefined };
}) {
  const settings = await getSettings();
  const allGames = await getAllGames();
  
  // Filter games based on search parameters
  const category = searchParams.category as string | undefined;
  const mobileOnly = searchParams.mobile === 'true';
  
  let filteredGames = allGames;
  
  // This is a simplified filter since we don't have category in our schema
  // In a real implementation, we would have a categories table and relation
  if (category) {
    // For demo purposes, just filter by title containing the category
    filteredGames = filteredGames.filter(game => 
      game.title.toLowerCase().includes(category.toLowerCase()) ||
      game.description.toLowerCase().includes(category.toLowerCase())
    );
  }
  
  if (mobileOnly) {
    filteredGames = filteredGames.filter(game => game.mobile_compatible === 1);
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header siteName={settings.site_name} />
      
      <main className="flex-grow">
        <section className="py-8 bg-gray-100 dark:bg-gray-900">
          <div className="container mx-auto px-4">
            <h1 className="text-3xl font-bold mb-6 text-gray-800 dark:text-white">Oyunlar</h1>
            
            {/* Filters */}
            <div className="mb-8 p-4 bg-white dark:bg-gray-800 rounded-lg shadow">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div className="flex flex-col md:flex-row gap-4">
                  <div>
                    <label htmlFor="category" className="form-label">Kategori</label>
                    <select 
                      id="category"
                      className="form-input"
                      defaultValue={category || ''}
                      onChange={(e) => {
                        const url = new URL(window.location.href);
                        if (e.target.value) {
                          url.searchParams.set('category', e.target.value);
                        } else {
                          url.searchParams.delete('category');
                        }
                        window.location.href = url.toString();
                      }}
                    >
                      <option value="">Tümü</option>
                      <option value="action">Aksiyon</option>
                      <option value="puzzle">Bulmaca</option>
                      <option value="strategy">Strateji</option>
                      <option value="arcade">Arcade</option>
                      <option value="sports">Spor</option>
                    </select>
                  </div>
                  
                  <div className="flex items-end">
                    <label className="inline-flex items-center">
                      <input 
                        type="checkbox" 
                        className="form-checkbox h-5 w-5 text-blue-600"
                        checked={mobileOnly}
                        onChange={(e) => {
                          const url = new URL(window.location.href);
                          if (e.target.checked) {
                            url.searchParams.set('mobile', 'true');
                          } else {
                            url.searchParams.delete('mobile');
                          }
                          window.location.href = url.toString();
                        }}
                      />
                      <span className="ml-2 text-gray-700 dark:text-gray-300">Sadece Mobil Uyumlu</span>
                    </label>
                  </div>
                </div>
                
                <div>
                  <label htmlFor="sort" className="form-label">Sıralama</label>
                  <select 
                    id="sort"
                    className="form-input"
                    defaultValue="newest"
                    onChange={(e) => {
                      const url = new URL(window.location.href);
                      url.searchParams.set('sort', e.target.value);
                      window.location.href = url.toString();
                    }}
                  >
                    <option value="newest">En Yeni</option>
                    <option value="oldest">En Eski</option>
                    <option value="name">İsim (A-Z)</option>
                    <option value="name-desc">İsim (Z-A)</option>
                  </select>
                </div>
              </div>
            </div>
            
            {/* Games Grid */}
            <Suspense fallback={<div>Oyunlar yükleniyor...</div>}>
              {filteredGames.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                  {filteredGames.map(game => (
                    <GameCard key={game.id} game={game} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <h3 className="text-xl font-medium text-gray-700 dark:text-gray-300 mb-4">
                    Aradığınız kriterlere uygun oyun bulunamadı.
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-6">
                    Lütfen farklı filtreler deneyiniz veya tüm oyunları görüntüleyiniz.
                  </p>
                  <Link href="/games" className="btn-primary">
                    Tüm Oyunları Göster
                  </Link>
                </div>
              )}
            </Suspense>
          </div>
        </section>
      </main>
      
      <Footer siteName={settings.site_name} />
    </div>
  );
}
