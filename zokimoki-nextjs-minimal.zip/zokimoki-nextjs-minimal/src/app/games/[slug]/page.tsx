import { getSettings, getGameBySlug } from '@/lib/database';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import StarRating from '@/components/StarRating';
import Link from 'next/link';
import Image from 'next/image';
import { notFound } from 'next/navigation';

export const runtime = 'edge';

export default async function GameDetailPage({
  params,
}: {
  params: { slug: string };
}) {
  const settings = await getSettings();
  const game = await getGameBySlug(params.slug);
  
  if (!game) {
    notFound();
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header siteName={settings.site_name} />
      
      <main className="flex-grow">
        <section className="py-8">
          <div className="container mx-auto px-4">
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
              <div className="md:flex">
                {/* Game Image */}
                <div className="md:w-1/3 relative">
                  <div className="relative h-64 md:h-full w-full">
                    {game.thumbnail_url ? (
                      <Image 
                        src={game.thumbnail_url} 
                        alt={game.title}
                        fill
                        sizes="(max-width: 768px) 100vw, 33vw"
                        className="object-cover"
                      />
                    ) : (
                      <div className="w-full h-full bg-gray-300 dark:bg-gray-700 flex items-center justify-center">
                        <span className="text-gray-500 dark:text-gray-400">No Image</span>
                      </div>
                    )}
                    
                    {game.mobile_compatible === 1 && (
                      <div className="absolute top-4 left-4 bg-green-500 text-white text-xs px-2 py-1 rounded-full">
                        Mobil Uyumlu
                      </div>
                    )}
                  </div>
                </div>
                
                {/* Game Details */}
                <div className="md:w-2/3 p-6">
                  <div className="flex justify-between items-start">
                    <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-2">
                      {game.title}
                    </h1>
                    
                    <div className="flex items-center">
                      <StarRating initialRating={4} readOnly />
                      <span className="ml-2 text-gray-600 dark:text-gray-400">4.0/5</span>
                    </div>
                  </div>
                  
                  <p className="text-gray-600 dark:text-gray-400 mb-6">
                    {game.description}
                  </p>
                  
                  <div className="mb-6">
                    <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-2">
                      Oyun Bilgileri
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <span className="text-gray-600 dark:text-gray-400">Eklenme Tarihi:</span>
                        <span className="ml-2 text-gray-800 dark:text-white">
                          {new Date(game.created_at).toLocaleDateString('tr-TR')}
                        </span>
                      </div>
                      <div>
                        <span className="text-gray-600 dark:text-gray-400">Mobil Uyumlu:</span>
                        <span className="ml-2 text-gray-800 dark:text-white">
                          {game.mobile_compatible === 1 ? 'Evet' : 'Hayır'}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <Link 
                    href={`/play/${game.slug}`}
                    className="btn-primary inline-block text-center w-full md:w-auto"
                  >
                    Şimdi Oyna
                  </Link>
                </div>
              </div>
              
              {/* Game Reviews */}
              <div className="border-t border-gray-200 dark:border-gray-700 p-6">
                <h3 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">
                  Değerlendirmeler
                </h3>
                
                <div className="mb-6">
                  <div className="flex items-center mb-2">
                    <StarRating initialRating={0} />
                    <span className="ml-2 text-gray-600 dark:text-gray-400">Oyunu değerlendirin</span>
                  </div>
                  
                  <textarea 
                    className="form-input h-24"
                    placeholder="Bu oyun hakkında düşüncelerinizi yazın..."
                  ></textarea>
                  
                  <button className="btn-primary mt-2">
                    Değerlendirme Gönder
                  </button>
                </div>
                
                <div className="space-y-4">
                  <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <div className="font-medium text-gray-800 dark:text-white">Kullanıcı123</div>
                      <div className="flex items-center">
                        <StarRating initialRating={5} readOnly size="sm" />
                        <span className="ml-2 text-sm text-gray-600 dark:text-gray-400">5.0</span>
                      </div>
                    </div>
                    <p className="text-gray-600 dark:text-gray-400">
                      Harika bir oyun! Saatlerce oynayabiliyorum ve hiç sıkılmıyorum.
                    </p>
                  </div>
                  
                  <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <div className="font-medium text-gray-800 dark:text-white">Oyuncu456</div>
                      <div className="flex items-center">
                        <StarRating initialRating={4} readOnly size="sm" />
                        <span className="ml-2 text-sm text-gray-600 dark:text-gray-400">4.0</span>
                      </div>
                    </div>
                    <p className="text-gray-600 dark:text-gray-400">
                      Çok eğlenceli bir oyun, ancak bazen yavaşlıyor. Yine de tavsiye ederim.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      
      <Footer siteName={settings.site_name} />
    </div>
  );
}
