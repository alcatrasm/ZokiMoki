'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function AdminGamesPage() {
  const [isLoading, setIsLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [games, setGames] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  
  const router = useRouter();
  
  useEffect(() => {
    // Check if user is logged in and is admin
    const userToken = localStorage.getItem('userToken');
    const userRole = localStorage.getItem('userRole');
    
    if (!userToken || userRole !== 'admin') {
      router.push('/login');
      return;
    }
    
    setIsAdmin(true);
    
    // Fetch games data
    // In a real app, this would make an API call to get games data
    // For demo purposes, we'll just simulate data
    setTimeout(() => {
      setGames([
        {
          id: 1,
          title: 'Space Invaders',
          slug: 'space-invaders',
          description: 'Classic arcade game where you defend Earth from alien invaders.',
          thumbnail_url: 'https://example.com/space-invaders.jpg',
          mobile_compatible: 1,
          created_at: '2025-04-01T10:00:00Z'
        },
        {
          id: 2,
          title: 'Tetris',
          slug: 'tetris',
          description: 'Arrange falling blocks to create complete lines and score points.',
          thumbnail_url: 'https://example.com/tetris.jpg',
          mobile_compatible: 1,
          created_at: '2025-04-02T11:30:00Z'
        },
        {
          id: 3,
          title: '2048',
          slug: '2048',
          description: 'Slide numbered tiles and combine them to reach the 2048 tile.',
          thumbnail_url: 'https://example.com/2048.jpg',
          mobile_compatible: 1,
          created_at: '2025-04-03T14:15:00Z'
        },
        {
          id: 4,
          title: 'Snake',
          slug: 'snake',
          description: 'Control a growing snake and avoid collisions while collecting food.',
          thumbnail_url: 'https://example.com/snake.jpg',
          mobile_compatible: 0,
          created_at: '2025-04-04T09:45:00Z'
        },
        {
          id: 5,
          title: 'Pac-Man',
          slug: 'pac-man',
          description: 'Navigate a maze, eating dots and avoiding ghosts.',
          thumbnail_url: 'https://example.com/pacman.jpg',
          mobile_compatible: 0,
          created_at: '2025-04-05T16:20:00Z'
        }
      ]);
      setIsLoading(false);
    }, 1000);
  }, [router]);
  
  const filteredGames = games.filter(game => 
    game.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    game.description.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const handleDelete = (id) => {
    if (window.confirm('Bu oyunu silmek istediğinizden emin misiniz?')) {
      // In a real app, this would make an API call to delete the game
      setGames(games.filter(game => game.id !== id));
    }
  };
  
  if (!isAdmin) {
    return null; // Don't render anything until we check authentication
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header siteName="Zokimoki Admin" />
      
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Oyun Yönetimi</h1>
            
            <div>
              <Link 
                href="/admin"
                className="text-blue-600 dark:text-blue-400 hover:underline mr-4"
              >
                Admin Paneline Dön
              </Link>
              
              <Link 
                href="/admin/game-add"
                className="btn-primary"
              >
                Yeni Oyun Ekle
              </Link>
            </div>
          </div>
          
          {/* Search and Filters */}
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 mb-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-grow">
                <label htmlFor="search" className="form-label">Oyun Ara</label>
                <input
                  type="text"
                  id="search"
                  className="form-input"
                  placeholder="Oyun adı veya açıklama..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              
              <div className="md:w-1/4">
                <label htmlFor="filter" className="form-label">Filtrele</label>
                <select id="filter" className="form-input">
                  <option value="">Tümü</option>
                  <option value="mobile">Mobil Uyumlu</option>
                  <option value="desktop">Sadece Masaüstü</option>
                </select>
              </div>
            </div>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full">
                  <thead>
                    <tr className="bg-gray-100 dark:bg-gray-700">
                      <th className="px-4 py-3 text-left text-gray-700 dark:text-gray-300">ID</th>
                      <th className="px-4 py-3 text-left text-gray-700 dark:text-gray-300">Oyun Adı</th>
                      <th className="px-4 py-3 text-left text-gray-700 dark:text-gray-300">Açıklama</th>
                      <th className="px-4 py-3 text-left text-gray-700 dark:text-gray-300">Mobil Uyumlu</th>
                      <th className="px-4 py-3 text-left text-gray-700 dark:text-gray-300">Eklenme Tarihi</th>
                      <th className="px-4 py-3 text-left text-gray-700 dark:text-gray-300">İşlemler</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredGames.length > 0 ? (
                      filteredGames.map(game => (
                        <tr key={game.id} className="border-t border-gray-200 dark:border-gray-700">
                          <td className="px-4 py-3 text-gray-800 dark:text-gray-200">{game.id}</td>
                          <td className="px-4 py-3 text-gray-800 dark:text-gray-200">{game.title}</td>
                          <td className="px-4 py-3 text-gray-800 dark:text-gray-200 truncate max-w-xs">{game.description}</td>
                          <td className="px-4 py-3 text-gray-800 dark:text-gray-200">
                            {game.mobile_compatible === 1 ? (
                              <span className="badge-success">Evet</span>
                            ) : (
                              <span className="badge-danger">Hayır</span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-gray-800 dark:text-gray-200">
                            {new Date(game.created_at).toLocaleDateString('tr-TR')}
                          </td>
                          <td className="px-4 py-3 text-gray-800 dark:text-gray-200">
                            <div className="flex space-x-2">
                              <Link 
                                href={`/games/${game.slug}`}
                                className="text-blue-600 dark:text-blue-400 hover:underline"
                                target="_blank"
                              >
                                Görüntüle
                              </Link>
                              <Link 
                                href={`/admin/game-edit/${game.id}`}
                                className="text-yellow-600 dark:text-yellow-400 hover:underline"
                              >
                                Düzenle
                              </Link>
                              <button 
                                onClick={() => handleDelete(game.id)}
                                className="text-red-600 dark:text-red-400 hover:underline"
                              >
                                Sil
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={6} className="px-4 py-6 text-center text-gray-500 dark:text-gray-400">
                          Arama kriterlerinize uygun oyun bulunamadı.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
              
              {/* Pagination */}
              <div className="px-4 py-3 bg-gray-50 dark:bg-gray-700 border-t border-gray-200 dark:border-gray-800 flex items-center justify-between">
                <div className="text-gray-600 dark:text-gray-300">
                  Toplam {filteredGames.length} oyun
                </div>
                
                <div className="flex space-x-2">
                  <button className="px-3 py-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded text-gray-700 dark:text-gray-300">
                    Önceki
                  </button>
                  <button className="px-3 py-1 bg-blue-600 text-white rounded">
                    1
                  </button>
                  <button className="px-3 py-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded text-gray-700 dark:text-gray-300">
                    2
                  </button>
                  <button className="px-3 py-1 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded text-gray-700 dark:text-gray-300">
                    Sonraki
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
      
      <Footer siteName="Zokimoki Admin" />
    </div>
  );
}
