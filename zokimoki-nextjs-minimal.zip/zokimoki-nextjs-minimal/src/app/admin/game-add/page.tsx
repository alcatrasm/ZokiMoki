'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function AdminGameAddPage() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    slug: '',
    description: '',
    embed_url: '',
    thumbnail_url: '',
    mobile_compatible: false
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  
  const router = useRouter();
  
  useEffect(() => {
    // Check if user is logged in and is admin
    const userToken = localStorage.getItem('userToken');
    const userRole = localStorage.getItem('userRole');
    
    if (!userToken || userRole !== 'admin') {
      router.push('/login');
      return;
    }
    
    setIsAdmin(true);
  }, [router]);
  
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
    
    // Auto-generate slug from title
    if (name === 'title') {
      const slug = value
        .toLowerCase()
        .replace(/[^\w\s-]/g, '') // Remove special characters
        .replace(/\s+/g, '-') // Replace spaces with hyphens
        .replace(/--+/g, '-'); // Replace multiple hyphens with single hyphen
      
      setFormData(prev => ({
        ...prev,
        slug
      }));
    }
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess(false);
    setIsLoading(true);
    
    try {
      // Validate form
      if (!formData.title || !formData.slug || !formData.description || !formData.embed_url) {
        setError('Lütfen tüm gerekli alanları doldurun.');
        setIsLoading(false);
        return;
      }
      
      // In a real app, this would make an API call to add the game
      // For demo purposes, we'll just simulate a successful addition
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Show success message
      setSuccess(true);
      
      // Reset form after success
      setFormData({
        title: '',
        slug: '',
        description: '',
        embed_url: '',
        thumbnail_url: '',
        mobile_compatible: false
      });
    } catch (err) {
      setError('Oyun eklenirken bir hata oluştu. Lütfen tekrar deneyin.');
    } finally {
      setIsLoading(false);
    }
  };
  
  if (!isAdmin) {
    return null; // Don't render anything until we check authentication
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header siteName="Zokimoki Admin" />
      
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Yeni Oyun Ekle</h1>
            
            <div>
              <Link 
                href="/admin/games"
                className="text-blue-600 dark:text-blue-400 hover:underline"
              >
                Oyun Listesine Dön
              </Link>
            </div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            {error && (
              <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
                <span className="block sm:inline">{error}</span>
              </div>
            )}
            
            {success && (
              <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
                <span className="block sm:inline">Oyun başarıyla eklendi!</span>
              </div>
            )}
            
            <form onSubmit={handleSubmit}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="title" className="form-label">Oyun Adı <span className="text-red-500">*</span></label>
                  <input
                    type="text"
                    id="title"
                    name="title"
                    className="form-input"
                    value={formData.title}
                    onChange={handleChange}
                    required
                  />
                </div>
                
                <div>
                  <label htmlFor="slug" className="form-label">Slug <span className="text-red-500">*</span></label>
                  <input
                    type="text"
                    id="slug"
                    name="slug"
                    className="form-input"
                    value={formData.slug}
                    onChange={handleChange}
                    required
                  />
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    URL'de kullanılacak benzersiz tanımlayıcı. Otomatik oluşturulur.
                  </p>
                </div>
                
                <div className="md:col-span-2">
                  <label htmlFor="description" className="form-label">Açıklama <span className="text-red-500">*</span></label>
                  <textarea
                    id="description"
                    name="description"
                    rows={4}
                    className="form-input"
                    value={formData.description}
                    onChange={handleChange}
                    required
                  ></textarea>
                </div>
                
                <div>
                  <label htmlFor="embed_url" className="form-label">Embed URL <span className="text-red-500">*</span></label>
                  <input
                    type="url"
                    id="embed_url"
                    name="embed_url"
                    className="form-input"
                    value={formData.embed_url}
                    onChange={handleChange}
                    required
                  />
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Oyunun iframe içinde gösterilecek URL'si.
                  </p>
                </div>
                
                <div>
                  <label htmlFor="thumbnail_url" className="form-label">Thumbnail URL</label>
                  <input
                    type="url"
                    id="thumbnail_url"
                    name="thumbnail_url"
                    className="form-input"
                    value={formData.thumbnail_url}
                    onChange={handleChange}
                  />
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Oyunun önizleme görseli için URL.
                  </p>
                </div>
                
                <div className="md:col-span-2">
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="mobile_compatible"
                      name="mobile_compatible"
                      className="h-5 w-5 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                      checked={formData.mobile_compatible}
                      onChange={handleChange}
                    />
                    <label htmlFor="mobile_compatible" className="ml-2 block text-gray-700 dark:text-gray-300">
                      Mobil Uyumlu
                    </label>
                  </div>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Bu oyun mobil cihazlarda düzgün çalışıyorsa işaretleyin.
                  </p>
                </div>
                
                <div className="md:col-span-2 border-t border-gray-200 dark:border-gray-700 pt-6">
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="btn-primary"
                  >
                    {isLoading ? 'Ekleniyor...' : 'Oyunu Ekle'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </main>
      
      <Footer siteName="Zokimoki Admin" />
    </div>
  );
}
