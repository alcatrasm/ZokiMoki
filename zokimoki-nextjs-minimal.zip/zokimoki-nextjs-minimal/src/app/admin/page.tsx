'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

export default function AdminDashboardPage() {
  const [isLoading, setIsLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalGames: 0,
    activeUsers: 0,
    dailySessions: 0
  });
  
  const router = useRouter();
  
  useEffect(() => {
    // Check if user is logged in and is admin
    const userToken = localStorage.getItem('userToken');
    const userRole = localStorage.getItem('userRole');
    
    if (!userToken || userRole !== 'admin') {
      router.push('/login');
      return;
    }
    
    setIsAdmin(true);
    
    // Fetch dashboard data
    // In a real app, this would make an API call to get dashboard data
    // For demo purposes, we'll just simulate data
    setTimeout(() => {
      setStats({
        totalUsers: 1254,
        totalGames: 87,
        activeUsers: 342,
        dailySessions: 1876
      });
      setIsLoading(false);
    }, 1000);
  }, [router]);
  
  if (!isAdmin) {
    return null; // Don't render anything until we check authentication
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header siteName="Zokimoki Admin" />
      
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Admin Paneli</h1>
            
            <div>
              <Link 
                href="/"
                className="text-blue-600 dark:text-blue-400 hover:underline"
              >
                Siteye Dön
              </Link>
            </div>
          </div>
          
          {isLoading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : (
            <>
              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-blue-100 dark:bg-blue-900 mr-4">
                      <svg className="h-8 w-8 text-blue-600 dark:text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                      </svg>
                    </div>
                    <div>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">Toplam Kullanıcı</p>
                      <p className="text-2xl font-bold text-gray-800 dark:text-white">{stats.totalUsers}</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-green-100 dark:bg-green-900 mr-4">
                      <svg className="h-8 w-8 text-green-600 dark:text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 3.055A9.001 9.001 0 1020.945 13H11V3.055z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.488 9H15V3.512A9.025 9.025 0 0120.488 9z" />
                      </svg>
                    </div>
                    <div>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">Toplam Oyun</p>
                      <p className="text-2xl font-bold text-gray-800 dark:text-white">{stats.totalGames}</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-yellow-100 dark:bg-yellow-900 mr-4">
                      <svg className="h-8 w-8 text-yellow-600 dark:text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">Aktif Kullanıcı</p>
                      <p className="text-2xl font-bold text-gray-800 dark:text-white">{stats.activeUsers}</p>
                    </div>
                  </div>
                </div>
                
                <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-purple-100 dark:bg-purple-900 mr-4">
                      <svg className="h-8 w-8 text-purple-600 dark:text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 15l-2 5L9 9l11 4-5 2zm0 0l5 5M7.188 2.239l.777 2.897M5.136 7.965l-2.898-.777M13.95 4.05l-2.122 2.122m-5.657 5.656l-2.12 2.122" />
                      </svg>
                    </div>
                    <div>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">Günlük Oturum</p>
                      <p className="text-2xl font-bold text-gray-800 dark:text-white">{stats.dailySessions}</p>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Admin Menu */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                <Link 
                  href="/admin/games"
                  className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-blue-100 dark:bg-blue-900 mr-4">
                      <svg className="h-6 w-6 text-blue-600 dark:text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-800 dark:text-white">Oyun Yönetimi</h3>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">Oyunları ekle, düzenle ve sil</p>
                    </div>
                  </div>
                </Link>
                
                <Link 
                  href="/admin/users"
                  className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-green-100 dark:bg-green-900 mr-4">
                      <svg className="h-6 w-6 text-green-600 dark:text-green-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-800 dark:text-white">Kullanıcı Yönetimi</h3>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">Kullanıcıları görüntüle ve yönet</p>
                    </div>
                  </div>
                </Link>
                
                <Link 
                  href="/admin/battle-pass"
                  className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-purple-100 dark:bg-purple-900 mr-4">
                      <svg className="h-6 w-6 text-purple-600 dark:text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-800 dark:text-white">Battle Pass</h3>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">Sezonları ve ödülleri yönet</p>
                    </div>
                  </div>
                </Link>
                
                <Link 
                  href="/admin/levels"
                  className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-yellow-100 dark:bg-yellow-900 mr-4">
                      <svg className="h-6 w-6 text-yellow-600 dark:text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-800 dark:text-white">Seviyeler ve Görevler</h3>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">XP seviyelerini ve görevleri yönet</p>
                    </div>
                  </div>
                </Link>
                
                <Link 
                  href="/admin/ads"
                  className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-red-100 dark:bg-red-900 mr-4">
                      <svg className="h-6 w-6 text-red-600 dark:text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 4a2 2 0 114 0v1a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-1a2 2 0 100 4h1a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-1a2 2 0 10-4 0v1a1 1 0 01-1 1H7a1 1 0 01-1-1v-3a1 1 0 00-1-1H4a2 2 0 110-4h1a1 1 0 001-1V7a1 1 0 011-1h3a1 1 0 001-1V4z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-800 dark:text-white">Reklam Yönetimi</h3>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">Reklam yerleşimlerini ve kodlarını yönet</p>
                    </div>
                  </div>
                </Link>
                
                <Link 
                  href="/admin/settings"
                  className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
                >
                  <div className="flex items-center">
                    <div className="p-3 rounded-full bg-gray-100 dark:bg-gray-700 mr-4">
                      <svg className="h-6 w-6 text-gray-600 dark:text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                      </svg>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-800 dark:text-white">Site Ayarları</h3>
                      <p className="text-gray-500 dark:text-gray-400 text-sm">Genel site ayarlarını yapılandır</p>
                    </div>
                  </div>
                </Link>
              </div>
              
              {/* Recent Activity */}
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                <h2 className="text-xl font-bold text-gray-800 dark:text-white mb-4">Son Aktiviteler</h2>
                
                <div className="overflow-x-auto">
                  <table className="min-w-full">
                    <thead>
                      <tr className="border-b border-gray-200 dark:border-gray-700">
                        <th className="px-4 py-2 text-left text-gray-500 dark:text-gray-400">Kullanıcı</th>
                        <th className="px-4 py-2 text-left text-gray-500 dark:text-gray-400">İşlem</th>
                        <th className="px-4 py-2 text-left text-gray-500 dark:text-gray-400">Detay</th>
                        <th className="px-4 py-2 text-left text-gray-500 dark:text-gray-400">Tarih</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b border-gray-200 dark:border-gray-700">
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">user123</td>
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">Kayıt</td>
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">Yeni kullanıcı kaydı</td>
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">22 Nis 2025, 10:15</td>
                      </tr>
                      <tr className="border-b border-gray-200 dark:border-gray-700">
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">admin</td>
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">Oyun Ekleme</td>
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">Yeni oyun: "Space Invaders"</td>
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">22 Nis 2025, 09:30</td>
                      </tr>
                      <tr className="border-b border-gray-200 dark:border-gray-700">
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">gamer456</td>
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">Oyun Oynama</td>
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">"Tetris" oynadı</td>
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">22 Nis 2025, 08:45</td>
                      </tr>
                      <tr className="border-b border-gray-200 dark:border-gray-700">
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">player789</td>
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">Değerlendirme</td>
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">"2048" oyununu değerlendirdi</td>
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">21 Nis 2025, 22:10</td>
                      </tr>
                      <tr className="border-b border-gray-200 dark:border-gray-700">
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">admin</td>
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">Ayar Değişikliği</td>
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">Site adı güncellendi</td>
                        <td className="px-4 py-3 text-gray-800 dark:text-gray-200">21 Nis 2025, 16:20</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>
      </main>
      
      <Footer siteName="Zokimoki Admin" />
    </div>
  );
}
