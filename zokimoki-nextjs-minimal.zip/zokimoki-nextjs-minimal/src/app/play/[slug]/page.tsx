import { getSettings, getGameBySlug } from '@/lib/database';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { notFound } from 'next/navigation';

export const runtime = 'edge';

export default async function PlayGamePage({
  params,
}: {
  params: { slug: string };
}) {
  const settings = await getSettings();
  const game = await getGameBySlug(params.slug);
  
  if (!game) {
    notFound();
  }
  
  return (
    <div className="flex flex-col min-h-screen">
      <div className="bg-black text-white p-2 flex justify-between items-center transition-all duration-300 ease-in-out" id="game-header">
        <Link href={`/games/${game.slug}`} className="text-white hover:text-gray-300">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
        </Link>
        
        <h1 className="text-lg font-bold">{game.title}</h1>
        
        <button 
          id="fullscreen-toggle"
          className="text-white hover:text-gray-300"
          aria-label="Toggle fullscreen"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5v-4m0 4h-4m4 0l-5-5" />
          </svg>
        </button>
      </div>
      
      <main className="flex-grow bg-black">
        <div className="w-full h-full">
          <iframe 
            src={game.embed_url}
            className="w-full h-screen border-0"
            allowFullScreen
            title={game.title}
          ></iframe>
        </div>
      </main>
      
      {/* Game Survey */}
      <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-800 p-4 shadow-lg transform transition-transform duration-300 ease-in-out" id="survey-container">
        <div className="container mx-auto max-w-2xl">
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-2">
            Bu oyun cihazınızda sorunsuz çalıştı mı?
          </h3>
          
          <div className="flex space-x-4">
            <button className="btn-primary" id="survey-yes">
              Evet, sorunsuz çalıştı
            </button>
            
            <button className="btn-secondary" id="survey-no">
              Hayır, sorunlar yaşadım
            </button>
            
            <button className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200" id="survey-close">
              Kapat
            </button>
          </div>
        </div>
      </div>
      
      {/* Client-side script for game page interactions */}
      <script dangerouslySetInnerHTML={{
        __html: `
          document.addEventListener('DOMContentLoaded', function() {
            const header = document.getElementById('game-header');
            const fullscreenToggle = document.getElementById('fullscreen-toggle');
            const surveyContainer = document.getElementById('survey-container');
            const surveyYes = document.getElementById('survey-yes');
            const surveyNo = document.getElementById('survey-no');
            const surveyClose = document.getElementById('survey-close');
            
            // Auto-hide header after 3 seconds
            setTimeout(() => {
              header.classList.add('-translate-y-full');
            }, 3000);
            
            // Show header on mouse move near top
            document.addEventListener('mousemove', (e) => {
              if (e.clientY < 50) {
                header.classList.remove('-translate-y-full');
              } else if (e.clientY > 100) {
                header.classList.add('-translate-y-full');
              }
            });
            
            // Fullscreen toggle
            fullscreenToggle.addEventListener('click', () => {
              if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen().catch(err => {
                  console.error('Error attempting to enable fullscreen:', err);
                });
              } else {
                if (document.exitFullscreen) {
                  document.exitFullscreen();
                }
              }
            });
            
            // Survey interactions
            surveyYes.addEventListener('click', () => {
              // In a real app, this would send data to the server
              console.log('Survey response: Yes');
              surveyContainer.classList.add('translate-y-full');
              
              // Show thank you message
              setTimeout(() => {
                surveyContainer.innerHTML = '<div class="container mx-auto max-w-2xl text-center"><p class="text-green-600 dark:text-green-400">Teşekkürler! Geri bildiriminiz kaydedildi.</p></div>';
                surveyContainer.classList.remove('translate-y-full');
                
                // Hide after 2 seconds
                setTimeout(() => {
                  surveyContainer.classList.add('translate-y-full');
                }, 2000);
              }, 500);
            });
            
            surveyNo.addEventListener('click', () => {
              // In a real app, this would send data to the server
              console.log('Survey response: No');
              surveyContainer.classList.add('translate-y-full');
              
              // Show thank you message
              setTimeout(() => {
                surveyContainer.innerHTML = '<div class="container mx-auto max-w-2xl text-center"><p class="text-green-600 dark:text-green-400">Teşekkürler! Geri bildiriminiz kaydedildi.</p></div>';
                surveyContainer.classList.remove('translate-y-full');
                
                // Hide after 2 seconds
                setTimeout(() => {
                  surveyContainer.classList.add('translate-y-full');
                }, 2000);
              }, 500);
            });
            
            surveyClose.addEventListener('click', () => {
              surveyContainer.classList.add('translate-y-full');
            });
          });
        `
      }} />
    </div>
  );
}
