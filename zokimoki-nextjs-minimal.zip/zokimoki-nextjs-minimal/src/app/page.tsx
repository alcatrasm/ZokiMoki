import { getSettings, getFeaturedGames, getTopLeaderboard } from '@/lib/database';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import GameCard from '@/components/GameCard';
import LeaderboardTable from '@/components/LeaderboardTable';
import Link from 'next/link';

export const runtime = 'edge';

export default async function Home() {
  const settings = await getSettings();
  const featuredGames = await getFeaturedGames(6);
  const dailyLeaderboard = await getTopLeaderboard('daily', 5);
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header siteName={settings.site_name} />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white py-16">
          <div className="container mx-auto text-center px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              {settings.site_name} - HTML5 Oyun Platformu
            </h1>
            <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
              En iyi HTML5 oyunları oynayabileceğiniz modern bir oyun platformu. Hemen oynamaya başlayın!
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link href="/games" className="btn-primary text-lg py-3 px-8">
                Oyunları Keşfet
              </Link>
              <Link href="/register" className="bg-white text-blue-600 hover:bg-gray-100 font-bold py-3 px-8 rounded text-lg">
                Ücretsiz Kayıt Ol
              </Link>
            </div>
          </div>
        </section>
        
        {/* Featured Games */}
        <section className="py-12 bg-gray-100 dark:bg-gray-900">
          <div className="container mx-auto px-4">
            <div className="flex justify-between items-center mb-8">
              <h2 className="section-title">Öne Çıkan Oyunlar</h2>
              <Link href="/games" className="text-blue-600 dark:text-blue-400 font-medium hover:underline">
                Tümünü Gör
              </Link>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6">
              {featuredGames.map(game => (
                <GameCard key={game.id} game={game} />
              ))}
            </div>
          </div>
        </section>
        
        {/* Categories */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <h2 className="section-title text-center mb-8">Kategoriler</h2>
            
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {['Aksiyon', 'Bulmaca', 'Strateji', 'Arcade', 'Spor'].map((category, index) => (
                <Link 
                  key={index}
                  href={`/games?category=${category.toLowerCase()}`}
                  className="card p-6 text-center hover:shadow-lg transition-shadow"
                >
                  <h3 className="font-bold text-gray-800 dark:text-white">{category}</h3>
                </Link>
              ))}
            </div>
          </div>
        </section>
        
        {/* Battle Pass Promo */}
        <section className="py-12 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center justify-between">
              <div className="md:w-1/2 mb-8 md:mb-0">
                <h2 className="text-3xl font-bold mb-4">Battle Pass</h2>
                <p className="text-lg mb-6">
                  Oyun oynayarak XP kazanın, seviye atlayın ve özel ödüller kazanın!
                  Battle Pass ile oyun deneyiminizi bir üst seviyeye taşıyın.
                </p>
                <Link href="/battle-pass" className="bg-white text-purple-600 hover:bg-gray-100 font-bold py-2 px-6 rounded">
                  Daha Fazla Bilgi
                </Link>
              </div>
              <div className="md:w-1/2 flex justify-center">
                <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 w-full max-w-md">
                  <h3 className="text-xl font-bold mb-4">Battle Pass Ödülleri</h3>
                  <ul className="space-y-3">
                    <li className="flex items-center justify-between">
                      <span>Seviye 1</span>
                      <span className="badge bg-white/20">Profil Rozeti</span>
                    </li>
                    <li className="flex items-center justify-between">
                      <span>Seviye 5</span>
                      <span className="badge bg-white/20">Özel Avatar</span>
                    </li>
                    <li className="flex items-center justify-between">
                      <span>Seviye 10</span>
                      <span className="badge bg-white/20">XP Çarpanı</span>
                    </li>
                    <li className="flex items-center justify-between">
                      <span>Seviye 20</span>
                      <span className="badge bg-white/20">VIP Erişim</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Leaderboard & Features */}
        <section className="py-12 bg-gray-100 dark:bg-gray-900">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Leaderboard */}
              <div>
                <LeaderboardTable leaderboards={dailyLeaderboard} period="daily" />
              </div>
              
              {/* Features */}
              <div className="card p-6">
                <h3 className="font-bold text-xl mb-6 text-gray-800 dark:text-white">
                  Neden Zokimoki?
                </h3>
                
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="flex-shrink-0 bg-blue-100 dark:bg-blue-900 p-2 rounded-full mr-4">
                      <svg className="h-6 w-6 text-blue-600 dark:text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-800 dark:text-white">Geniş Oyun Kütüphanesi</h4>
                      <p className="text-gray-600 dark:text-gray-400">Yüzlerce HTML5 oyunu tek bir platformda</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="flex-shrink-0 bg-blue-100 dark:bg-blue-900 p-2 rounded-full mr-4">
                      <svg className="h-6 w-6 text-blue-600 dark:text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-800 dark:text-white">Mobil Uyumlu</h4>
                      <p className="text-gray-600 dark:text-gray-400">Tüm cihazlarda sorunsuz oyun deneyimi</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="flex-shrink-0 bg-blue-100 dark:bg-blue-900 p-2 rounded-full mr-4">
                      <svg className="h-6 w-6 text-blue-600 dark:text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-800 dark:text-white">Kullanıcı Profilleri</h4>
                      <p className="text-gray-600 dark:text-gray-400">İlerlemenizi takip edin ve ödüller kazanın</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="flex-shrink-0 bg-blue-100 dark:bg-blue-900 p-2 rounded-full mr-4">
                      <svg className="h-6 w-6 text-blue-600 dark:text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-800 dark:text-white">Güvenli ve Ücretsiz</h4>
                      <p className="text-gray-600 dark:text-gray-400">Reklamsız ve güvenli bir oyun ortamı</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Call to Action */}
        <section className="py-16 bg-blue-600 text-white text-center">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold mb-4">Hemen Oynamaya Başlayın</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">
              Ücretsiz hesap oluşturun ve hemen oynamaya başlayın. İlerlemenizi kaydedin, ödüller kazanın ve liderlik tablolarında yerinizi alın.
            </p>
            <Link href="/register" className="bg-white text-blue-600 hover:bg-gray-100 font-bold py-3 px-8 rounded-lg text-lg">
              Ücretsiz Kayıt Ol
            </Link>
          </div>
        </section>
      </main>
      
      <Footer siteName={settings.site_name} />
    </div>
  );
}
