'use client';

import { useState } from 'react';
import { Leaderboard } from '@/lib/database';
import Link from 'next/link';

interface LeaderboardTableProps {
  leaderboards: Leaderboard[];
  period: string;
}

export default function LeaderboardTable({ leaderboards, period }: LeaderboardTableProps) {
  const [activePeriod, setActivePeriod] = useState(period);
  
  const periodLabels = {
    'daily': 'Günlük',
    'weekly': 'Haftalık',
    'all-time': 'Tüm Zamanlar'
  };
  
  return (
    <div className="card">
      <div className="bg-gray-100 dark:bg-gray-700 px-4 py-3 flex justify-between items-center">
        <h3 className="font-bold text-gray-800 dark:text-white">Liderlik Tablosu</h3>
        
        <div className="flex space-x-2">
          {Object.entries(periodLabels).map(([key, label]) => (
            <button
              key={key}
              className={`px-3 py-1 text-sm rounded-md ${
                activePeriod === key
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 dark:bg-gray-600 text-gray-700 dark:text-gray-300'
              }`}
              onClick={() => setActivePeriod(key)}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
      
      <div className="p-4">
        {leaderboards.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="border-b border-gray-200 dark:border-gray-700">
                  <th className="px-4 py-2 text-left text-gray-500 dark:text-gray-400">Sıra</th>
                  <th className="px-4 py-2 text-left text-gray-500 dark:text-gray-400">Kullanıcı</th>
                  <th className="px-4 py-2 text-right text-gray-500 dark:text-gray-400">Puan</th>
                </tr>
              </thead>
              <tbody>
                {leaderboards.map((entry, index) => (
                  <tr 
                    key={entry.id}
                    className="border-b border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800"
                  >
                    <td className="px-4 py-3 text-gray-800 dark:text-gray-200">
                      {index + 1}
                    </td>
                    <td className="px-4 py-3 text-gray-800 dark:text-gray-200">
                      <Link 
                        href={`/profile/${entry.user_id}`}
                        className="hover:text-blue-600 dark:hover:text-blue-400"
                      >
                        {entry.username}
                      </Link>
                    </td>
                    <td className="px-4 py-3 text-right font-medium text-gray-800 dark:text-gray-200">
                      {entry.score.toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            Bu dönem için henüz liderlik tablosu verisi bulunmamaktadır.
          </div>
        )}
        
        <div className="mt-4 text-center">
          <Link 
            href="/leaderboard"
            className="text-blue-600 dark:text-blue-400 text-sm font-medium hover:underline"
          >
            Tam Liderlik Tablosunu Görüntüle
          </Link>
        </div>
      </div>
    </div>
  );
}
