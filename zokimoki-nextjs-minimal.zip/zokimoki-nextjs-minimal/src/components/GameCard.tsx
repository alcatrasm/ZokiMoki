'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Game } from '@/lib/database';

interface GameCardProps {
  game: Game;
}

export default function GameCard({ game }: GameCardProps) {
  return (
    <div className="game-card relative">
      <div className="relative h-40 w-full">
        {game.thumbnail_url ? (
          <Image 
            src={game.thumbnail_url} 
            alt={game.title}
            fill
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            className="object-cover"
          />
        ) : (
          <div className="w-full h-full bg-gray-300 dark:bg-gray-700 flex items-center justify-center">
            <span className="text-gray-500 dark:text-gray-400">No Image</span>
          </div>
        )}
        
        {game.mobile_compatible === 1 && (
          <div className="mobile-compatible-badge">
            Mobil Uyumlu
          </div>
        )}
      </div>
      
      <div className="p-4">
        <h3 className="text-lg font-semibold mb-2 text-gray-900 dark:text-white">
          {game.title}
        </h3>
        
        <p className="text-gray-600 dark:text-gray-400 text-sm mb-4 line-clamp-2">
          {game.description}
        </p>
        
        <div className="flex justify-between items-center">
          <Link 
            href={`/games/${game.slug}`}
            className="text-blue-600 dark:text-blue-400 text-sm font-medium hover:underline"
          >
            Detaylar
          </Link>
          
          <Link 
            href={`/play/${game.slug}`}
            className="btn-primary text-sm py-1 px-3"
          >
            Oyna
          </Link>
        </div>
      </div>
    </div>
  );
}
