import { D1Database } from '@cloudflare/workers-types';

export interface CloudflareContext {
  DB: D1Database;
}

export function getCloudflareContext(): CloudflareContext | null {
  if (typeof process.env.DB === 'undefined') {
    return null;
  }
  
  return {
    DB: process.env.DB as unknown as D1Database,
  };
}

export interface Game {
  id: number;
  title: string;
  slug: string;
  description: string;
  embed_url: string;
  thumbnail_url: string;
  mobile_compatible: number;
  created_at: string;
}

export interface User {
  id: number;
  email: string;
  status: string;
  created_at: string;
}

export interface UserProfile {
  user_id: number;
  username: string;
  avatar_url: string | null;
  bio: string | null;
}

export interface Level {
  level_number: number;
  required_xp: number;
  badge_name: string;
}

export interface Task {
  id: number;
  level_number: number;
  description: string;
  xp_reward: number;
  is_daily: number;
  is_weekly: number;
}

export interface BattlePass {
  id: number;
  season_name: string;
  start_date: string;
  end_date: string;
  status: string;
}

export interface BattlePassReward {
  id: number;
  battle_pass_id: number;
  level_number: number;
  reward_type: string;
  reward_value: string;
}

export interface Leaderboard {
  id: number;
  user_id: number;
  score: number;
  period: string;
  username?: string; // Joined from user_profiles
}

export interface Setting {
  key: string;
  value: string;
}

export async function getSettings(): Promise<Record<string, string>> {
  const ctx = getCloudflareContext();
  if (!ctx) {
    return {
      site_name: 'Zokimoki',
      site_description: 'The best HTML5 gaming platform',
      maintenance_mode: '0',
      registration_enabled: '1',
      default_theme: 'modern'
    };
  }

  const { results } = await ctx.DB.prepare('SELECT key, value FROM settings').all<Setting>();
  
  const settings: Record<string, string> = {};
  for (const row of results) {
    settings[row.key] = row.value;
  }
  
  return settings;
}

export async function getFeaturedGames(limit = 6): Promise<Game[]> {
  const ctx = getCloudflareContext();
  if (!ctx) {
    return [];
  }

  const { results } = await ctx.DB.prepare(
    'SELECT * FROM games ORDER BY id DESC LIMIT ?'
  ).bind(limit).all<Game>();
  
  return results;
}

export async function getAllGames(): Promise<Game[]> {
  const ctx = getCloudflareContext();
  if (!ctx) {
    return [];
  }

  const { results } = await ctx.DB.prepare(
    'SELECT * FROM games ORDER BY title ASC'
  ).all<Game>();
  
  return results;
}

export async function getGameBySlug(slug: string): Promise<Game | null> {
  const ctx = getCloudflareContext();
  if (!ctx) {
    return null;
  }

  const result = await ctx.DB.prepare(
    'SELECT * FROM games WHERE slug = ?'
  ).bind(slug).first<Game>();
  
  return result || null;
}

export async function getTopLeaderboard(period: string, limit = 10): Promise<Leaderboard[]> {
  const ctx = getCloudflareContext();
  if (!ctx) {
    return [];
  }

  const { results } = await ctx.DB.prepare(
    `SELECT l.*, up.username 
     FROM leaderboards l
     JOIN user_profiles up ON l.user_id = up.user_id
     WHERE l.period = ?
     ORDER BY l.score DESC
     LIMIT ?`
  ).bind(period, limit).all<Leaderboard>();
  
  return results;
}

export async function getUserById(userId: number): Promise<{ user: User; profile: UserProfile } | null> {
  const ctx = getCloudflareContext();
  if (!ctx) {
    return null;
  }

  const user = await ctx.DB.prepare(
    'SELECT * FROM users WHERE id = ?'
  ).bind(userId).first<User>();
  
  if (!user) {
    return null;
  }
  
  const profile = await ctx.DB.prepare(
    'SELECT * FROM user_profiles WHERE user_id = ?'
  ).bind(userId).first<UserProfile>();
  
  if (!profile) {
    return null;
  }
  
  return { user, profile };
}

export async function getCurrentBattlePass(): Promise<BattlePass | null> {
  const ctx = getCloudflareContext();
  if (!ctx) {
    return null;
  }

  const result = await ctx.DB.prepare(
    `SELECT * FROM battle_pass 
     WHERE status = 'active' 
     AND start_date <= datetime('now') 
     AND end_date >= datetime('now')
     LIMIT 1`
  ).first<BattlePass>();
  
  return result || null;
}

export async function getBattlePassRewards(battlePassId: number): Promise<BattlePassReward[]> {
  const ctx = getCloudflareContext();
  if (!ctx) {
    return [];
  }

  const { results } = await ctx.DB.prepare(
    'SELECT * FROM battle_pass_rewards WHERE battle_pass_id = ? ORDER BY level_number ASC'
  ).bind(battlePassId).all<BattlePassReward>();
  
  return results;
}

export async function getLevels(): Promise<Level[]> {
  const ctx = getCloudflareContext();
  if (!ctx) {
    return [];
  }

  const { results } = await ctx.DB.prepare(
    'SELECT * FROM levels ORDER BY level_number ASC'
  ).all<Level>();
  
  return results;
}

export async function getDailyTasks(): Promise<Task[]> {
  const ctx = getCloudflareContext();
  if (!ctx) {
    return [];
  }

  const { results } = await ctx.DB.prepare(
    'SELECT * FROM tasks WHERE is_daily = 1'
  ).all<Task>();
  
  return results;
}

export async function getWeeklyTasks(): Promise<Task[]> {
  const ctx = getCloudflareContext();
  if (!ctx) {
    return [];
  }

  const { results } = await ctx.DB.prepare(
    'SELECT * FROM tasks WHERE is_weekly = 1'
  ).all<Task>();
  
  return results;
}
