-- SQLite schema for zokimoki.com
-- This is a simplified version of the MySQL schema for deployment on Manus.ai

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- User profiles table
CREATE TABLE IF NOT EXISTS user_profiles (
    user_id INTEGER PRIMARY KEY,
    username TEXT NOT NULL UNIQUE,
    avatar_url TEXT,
    bio TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Games table
CREATE TABLE IF NOT EXISTS games (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    description TEXT,
    embed_url TEXT NOT NULL,
    thumbnail_url TEXT,
    mobile_compatible INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Levels table
CREATE TABLE IF NOT EXISTS levels (
    level_number INTEGER PRIMARY KEY,
    required_xp INTEGER NOT NULL,
    badge_name TEXT NOT NULL
);

-- Tasks table
CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    level_number INTEGER,
    description TEXT NOT NULL,
    xp_reward INTEGER NOT NULL,
    is_daily INTEGER DEFAULT 0,
    is_weekly INTEGER DEFAULT 0,
    FOREIGN KEY (level_number) REFERENCES levels(level_number)
);

-- Battle pass table
CREATE TABLE IF NOT EXISTS battle_pass (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    season_name TEXT NOT NULL,
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    status TEXT DEFAULT 'scheduled'
);

-- Battle pass rewards table
CREATE TABLE IF NOT EXISTS battle_pass_rewards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    battle_pass_id INTEGER NOT NULL,
    level_number INTEGER NOT NULL,
    reward_type TEXT NOT NULL,
    reward_value TEXT NOT NULL,
    FOREIGN KEY (battle_pass_id) REFERENCES battle_pass(id) ON DELETE CASCADE
);

-- Leaderboards table
CREATE TABLE IF NOT EXISTS leaderboards (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    score INTEGER NOT NULL,
    period TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Leaderboard archives table
CREATE TABLE IF NOT EXISTS leaderboard_archives (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    score INTEGER NOT NULL,
    period TEXT NOT NULL,
    archived_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Experience logs table
CREATE TABLE IF NOT EXISTS exp_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    xp_gained INTEGER NOT NULL,
    source TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Activity logs table
CREATE TABLE IF NOT EXISTS activity_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    action TEXT NOT NULL,
    details TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Ads table
CREATE TABLE IF NOT EXISTS ads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type TEXT NOT NULL,
    location TEXT NOT NULL,
    priority INTEGER DEFAULT 0
);

-- Settings table
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- Survey responses table
CREATE TABLE IF NOT EXISTS survey_responses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    game_id INTEGER NOT NULL,
    response TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    FOREIGN KEY (game_id) REFERENCES games(id) ON DELETE CASCADE
);

-- Insert sample data
-- Admin user
INSERT INTO users (email, password, status) VALUES ('admin@zokimoki.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'active');
INSERT INTO user_profiles (user_id, username) VALUES (1, 'Admin');

-- Sample games
INSERT INTO games (title, slug, description, embed_url, thumbnail_url, mobile_compatible) VALUES 
    ('2048', '2048', 'Join the numbers and get to the 2048 tile!', 'https://play2048.co/', 'https://play2048.co/meta/og_image.png', 1),
    ('Flappy Bird', 'flappy-bird', 'Guide the bird through pipes without touching them.', 'https://flappybird.io/', 'https://flappybird.io/thumb.png', 1),
    ('Tetris', 'tetris', 'Classic block-stacking puzzle game.', 'https://tetris.com/play-tetris', 'https://tetris.com/img/tetris-logo.png', 0);

-- Sample levels
INSERT INTO levels (level_number, required_xp, badge_name) VALUES 
    (1, 0, 'Newbie'),
    (2, 100, 'Rookie'),
    (3, 300, 'Explorer'),
    (4, 600, 'Adventurer'),
    (5, 1000, 'Master');

-- Sample tasks
INSERT INTO tasks (level_number, description, xp_reward, is_daily, is_weekly) VALUES 
    (1, 'Play a game', 10, 1, 0),
    (1, 'Rate a game', 5, 1, 0),
    (2, 'Play 5 different games', 50, 0, 1),
    (3, 'Achieve a high score', 30, 0, 1);

-- Sample settings
INSERT INTO settings (key, value) VALUES 
    ('site_name', 'Zokimoki'),
    ('site_description', 'The best HTML5 gaming platform'),
    ('maintenance_mode', '0'),
    ('registration_enabled', '1'),
    ('default_theme', 'modern');
